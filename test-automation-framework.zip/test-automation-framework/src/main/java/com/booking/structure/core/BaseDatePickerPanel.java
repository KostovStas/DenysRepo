package com.booking.structure.core;

public interface BaseDatePickerPanel {

    void selectDateByValue(final String value);
}
